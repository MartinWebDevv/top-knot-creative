function App() {
  return (
    <div>
      <h1 className="text-3xl font-bold text-purple-400">Tailwind is working</h1>
    </div>
  )
}

export default App